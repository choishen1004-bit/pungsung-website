document.addEventListener('DOMContentLoaded', () => {
  // Simple Netlify Forms success handler
  const forms = document.querySelectorAll('form[data-netlify="true"]');
  forms.forEach(f => {
    f.addEventListener('submit', () => {
      setTimeout(() => alert('접수되었습니다. 빠르게 회신드리겠습니다.'), 300);
    });
  });
});
