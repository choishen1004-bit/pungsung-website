# (주) 풍성공영 웹사이트 (정적 사이트)
- 생성: 2025-08-21 08:28
- 목적: 우레탄 뿜칠/단열/내화/방수 시공 리드(견적) 수집 및 소개

## 페이지
- / (홈): 핵심 가치/서비스 프리뷰/CTA
- /pages/services.html
- /pages/portfolio.html
- /pages/quote.html (Netlify Forms 기반 문의 폼)
- /pages/faq.html
- /pages/privacy.html

## 배포
GitHub Pages 또는 Netlify에 폴더 전체 업로드 후 사용하세요.

## 수정 포인트
- 회사 이메일/카카오톡 채널 URL, 실제 포트폴리오 사진 교체
- Netlify Forms 사용 시 빌드 설정 필요 없음(정적). 파일 업로드는 서버/Lambda 연동 필요.
